from django.shortcuts import render, redirect
from django.contrib import messages
from app.core.models import Utilisateur, Domaine, Besoin
from app.publications.models import Demande, DemandeDomaine, DemandeDisponibilite
from .forms import FormulaireDemande, JOURS_CHOICES, MOMENTS_CHOICES

def offres_view(request):
    if not request.session.get('verified_user_id'): 
        return redirect('connexion')
    user_id = request.session.get('verified_user_id')
    profil_metier = Utilisateur.objects.filter(id=user_id).first()
    return render(request, 'offres.html', {'titre_page': 'Offres', 'profil': profil_metier})


def demandes_view(request):
    # 1. Vérification de la connexion
    user_id = request.session.get('verified_user_id')
    if not user_id: 
        return redirect('connexion')
        
    profil_metier = Utilisateur.objects.filter(id=user_id).first()

    # 2. Récupération des besoins EXACTEMENT comme dans la page profil
    points_faibles = []
    if profil_metier:
        points_faibles = Besoin.objects.filter(utilisateur=profil_metier)

    # 3. Gestion de la soumission du formulaire (POST)
    if request.method == 'POST':
        # On récupère les IDs des matières cochées dans le HTML brut
        matieres_cochees_ids = request.POST.getlist('matieres_faibles')
        
        if matieres_cochees_ids:
            # Création de la demande (table publication)
            nouvelle_demande = Demande.objects.create(
                utilisateur=profil_metier,
                type='DEMANDE',
                statut='OUVERT'
            )
            
            # Enregistrement des domaines sélectionnés
            for m_id in matieres_cochees_ids:
                domaine_obj = Domaine.objects.filter(id=m_id).first()
                if domaine_obj:
                    DemandeDomaine.objects.create(demande=nouvelle_demande, domaine=domaine_obj)
                
            # Enregistrement des créneaux de disponibilités
            for jour_code, _ in JOURS_CHOICES:
                for moment_code, _ in MOMENTS_CHOICES:
                    input_name = f"dispo_{jour_code}_{moment_code}"
                    if request.POST.get(input_name) == "1":
                        DemandeDisponibilite.objects.create(
                            demande=nouvelle_demande,
                            jour_semaine=1, 
                            heure_debut="08:00:00",
                            heure_fin="18:00:00"
                        )
            
            messages.success(request, "Votre demande d'aide a été publiée avec succès !")
            return redirect('demandes')
    
    # 4. Historique des demandes de l'utilisateur
    if profil_metier:
        demandes_utilisateur = Demande.objects.filter(utilisateur=profil_metier, type='DEMANDE').order_by('-date_publication')
    else:
        demandes_utilisateur = Demande.objects.none()
    
    for d in demandes_utilisateur:
        d.matieres_list = Domaine.objects.filter(id__in=DemandeDomaine.objects.filter(demande=d).values_list('domaine_id', flat=True))
        d.dispos_list = DemandeDisponibilite.objects.filter(demande=d)

    context = {
        'titre_page': "Demandes d'Aide",
        'profil': profil_metier,
        'points_faibles': points_faibles,  # Passé directement pour le HTML
        'jours_choices': JOURS_CHOICES,
        'moments_choices': MOMENTS_CHOICES,
        'mes_demandes': demandes_utilisateur
    }
    return render(request, 'demandes.html', context)